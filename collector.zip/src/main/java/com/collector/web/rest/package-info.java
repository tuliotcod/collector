/**
 * Spring MVC REST controllers.
 */
package com.collector.web.rest;
