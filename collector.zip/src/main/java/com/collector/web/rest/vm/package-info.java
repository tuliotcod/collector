/**
 * View Models used by Spring MVC REST controllers.
 */
package com.collector.web.rest.vm;
