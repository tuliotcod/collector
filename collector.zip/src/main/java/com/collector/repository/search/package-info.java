/**
 * Spring Data Elasticsearch repositories.
 */
package com.collector.repository.search;
