/**
 * Service layer beans.
 */
package com.collector.service;
