/**
 * Data Transfer Objects.
 */
package com.collector.service.dto;
