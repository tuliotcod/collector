/**
 * JPA domain objects.
 */
package com.collector.domain;
