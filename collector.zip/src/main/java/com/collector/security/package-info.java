/**
 * Spring Security configuration.
 */
package com.collector.security;
