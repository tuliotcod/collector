/**
 * Spring Framework configuration files.
 */
package com.collector.config;
